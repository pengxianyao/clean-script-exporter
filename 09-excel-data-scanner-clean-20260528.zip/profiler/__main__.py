"""Entry point for the Excel Data Universe Profiler."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from profiler.column_profiler import profile_columns
from profiler.file_loader import load_workbook, pick_file
from profiler.header_resolver import resolve_headers
from profiler.output_writer import write_all_outputs
from profiler.profile_builder import build_profile
from profiler.relationship_detector import detect_relationships
from profiler.sequence_detector import detect_sequences
from profiler.sequence_prompter import prompt_sequence_columns, prompt_sequence_opt_in
from profiler.sheet_selector import select_sheet


def main() -> None:
    print("Excel Data Universe Profiler")
    print()

    try:
        _run()
    except (FileNotFoundError, ValueError) as exc:
        print(f"Error: {exc}")
        raise SystemExit(1)
    except KeyboardInterrupt:
        print("\nCancelled.")
        raise SystemExit(0)


def _run() -> None:
    path = pick_file()
    print(f"Loading: {path.name}")

    workbook = load_workbook(path)

    sheet_name = select_sheet(workbook.sheet_names)
    sheet_data = workbook.get_sheet_data(sheet_name)
    print(f"Sheet '{sheet_name}': {len(sheet_data)} rows")

    header_row, column_names = resolve_headers(sheet_data)
    print(f"Header row: {header_row}  |  Columns: {len(column_names)}")

    print("Profiling columns...")
    column_profiles = profile_columns(sheet_data, header_row, column_names)

    column_data = _extract_column_data(sheet_data, header_row, len(column_names))

    print("Detecting column relationships...")
    relationships = detect_relationships(column_names, column_data)
    exact_mappings = relationships["exact_mappings"]
    if exact_mappings:
        print(f"  Found {len(exact_mappings)} exact mapping(s)")
    extra_relationships = sum(
        len(items)
        for name, items in relationships.items()
        if name != "exact_mappings"
    )
    if extra_relationships:
        print(f"  Found {extra_relationships} additional relationship(s)")

    sequence_analysis = None
    if prompt_sequence_opt_in():
        grouping_col, sequence_col, ordering_col = prompt_sequence_columns(column_names)
        print("\nDetecting workflow sequences...")
        sequence_analysis = detect_sequences(
            column_names, column_data, grouping_col, sequence_col, ordering_col
        )
        print(f"  Groups: {sequence_analysis['total_groups']}")
        print(f"  Avg sequence length: {sequence_analysis['avg_sequence_length']}")
        print(f"  Transitions detected: {len(sequence_analysis['transitions'])}")

    total_rows = len(sheet_data) - header_row
    profile = build_profile(
        source_path=path,
        sheet_name=sheet_name,
        header_row=header_row,
        total_rows=total_rows,
        column_profiles=column_profiles,
        column_data=column_data,
        exact_mappings=exact_mappings,
        relationships=relationships,
        sequence_analysis=sequence_analysis,
    )

    outputs = write_all_outputs(profile, path)
    print()
    print(f"Outputs written to: {outputs['json'].parent}")
    for fmt, out_path in outputs.items():
        print(f"  {fmt.upper()}: {out_path.name}")


def _extract_column_data(
    sheet_data: list[list[Any]],
    header_row: int,
    num_cols: int,
) -> list[list[Any]]:
    data_rows = sheet_data[header_row:]
    return [
        [row[i] if i < len(row) else None for row in data_rows]
        for i in range(num_cols)
    ]


if __name__ == "__main__":
    main()
