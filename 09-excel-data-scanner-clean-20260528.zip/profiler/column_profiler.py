"""Per-column type inference and distribution summary."""
from __future__ import annotations

import datetime
import re
from typing import Any

_BOOLEAN_STRINGS = {"true", "false", "yes", "no", "y", "n", "1", "0"}
_CURRENCY_RE = re.compile(r"^[£$€¥₹]?[\d,]+(\.\d+)?[£$€¥₹]?$")
_CURRENCY_SYMBOLS = set("£$€¥₹")
_PERCENTAGE_RE = re.compile(r"^-?[\d,]+(\.\d+)?%$")


def profile_columns(
    sheet_data: list[list[Any]],
    header_row: int,
    column_names: list[str],
) -> list[dict[str, Any]]:
    # header_row is 1-indexed; data starts immediately after it
    data_rows = sheet_data[header_row:]
    profiles = []
    for col_idx, name in enumerate(column_names):
        values = [row[col_idx] if col_idx < len(row) else None for row in data_rows]
        profiles.append(_profile_column(col_idx, name, values))
    return profiles


def _profile_column(index: int, name: str, values: list[Any]) -> dict[str, Any]:
    total = len(values)
    non_null = [v for v in values if not _is_null(v)]
    null_count = total - len(non_null)
    null_pct = round(null_count / total * 100, 2) if total > 0 else 0.0
    unique_vals = {_key(v) for v in non_null}
    unique_count = len(unique_vals)
    unique_pct = round(unique_count / total * 100, 2) if total > 0 else 0.0

    inferred_type = _infer_type(non_null, unique_count, total)

    profile: dict[str, Any] = {
        "name": name,
        "index": index,
        "inferred_type": inferred_type,
        "total_count": total,
        "null_count": null_count,
        "null_pct": null_pct,
        "unique_count": unique_count,
        "unique_pct": unique_pct,
    }
    if inferred_type == "mixed":
        profile["mixed_types"] = _mixed_type_distribution(non_null, total)
    profile.update(_distribution(inferred_type, non_null, total))
    return profile


# --- Type inference -----------------------------------------------------------

def _infer_type(non_null: list[Any], unique_count: int, total: int) -> str:
    if not non_null:
        return "empty"

    null_pct = (total - len(non_null)) / total * 100 if total > 0 else 0.0
    if null_pct > 90:
        return "mostly_null"

    if all(isinstance(v, datetime.datetime) for v in non_null):
        return "datetime"
    if all(isinstance(v, datetime.date) for v in non_null):
        return "date"

    if _all_boolean(non_null):
        return "boolean"

    str_vals = [str(v).strip() for v in non_null]

    # Identifier check before categorical — structural signals (leading zeros,
    # fixed length, pattern) override low cardinality.
    if _is_identifier(non_null, str_vals):
        return "identifier"

    if unique_count <= 20 and all(isinstance(v, str) for v in non_null):
        return "categorical"

    if _all_integer(non_null):
        return "integer"

    if all(_matches_currency(s) for s in str_vals):
        return "currency"

    if all(_matches_percentage(s) for s in str_vals):
        return "percentage"

    if _all_float(non_null):
        return "float"

    if _is_mixed(non_null):
        return "mixed"

    return "string"


def _is_null(v: Any) -> bool:
    if v is None:
        return True
    return isinstance(v, str) and v.strip() == ""


def _key(v: Any) -> str:
    return str(v).strip().lower()


def _all_boolean(values: list[Any]) -> bool:
    for v in values:
        if isinstance(v, bool):
            continue
        if isinstance(v, str) and v.strip().lower() in _BOOLEAN_STRINGS:
            continue
        return False
    return bool(values)


def _is_identifier(values: list[Any], str_vals: list[str]) -> bool:
    if not all(isinstance(v, str) for v in values):
        return False
    return (
        _has_leading_zeros(str_vals)
        or _is_fixed_length(str_vals)
        or _has_identifier_pattern(str_vals)
    )


def _has_leading_zeros(str_vals: list[str]) -> bool:
    return any(len(s) > 1 and s[0] == "0" and s[1:].isdigit() for s in str_vals)


def _is_fixed_length(str_vals: list[str]) -> bool:
    lengths = {len(s) for s in str_vals}
    return len(lengths) == 1 and next(iter(lengths)) > 3


_IDENTIFIER_RE = re.compile(r"^[A-Z]{1,4}[0-9]+([-_][0-9]+)?$")


def _has_identifier_pattern(str_vals: list[str]) -> bool:
    if not str_vals:
        return False
    matches = sum(1 for s in str_vals if _IDENTIFIER_RE.match(s.upper()))
    return matches / len(str_vals) >= 0.8


def _all_integer(values: list[Any]) -> bool:
    for v in values:
        if isinstance(v, bool):
            return False
        if isinstance(v, int):
            continue
        if isinstance(v, float) and v == int(v):
            continue
        if isinstance(v, str):
            try:
                int(v.strip())
                continue
            except ValueError:
                return False
        return False
    return bool(values)


def _all_float(values: list[Any]) -> bool:
    for v in values:
        if isinstance(v, bool):
            return False
        if isinstance(v, (int, float)):
            continue
        if isinstance(v, str):
            try:
                float(v.strip().replace(",", ""))
                continue
            except ValueError:
                return False
        return False
    return bool(values)


def _matches_currency(s: str) -> bool:
    has_symbol = any(c in _CURRENCY_SYMBOLS for c in s)
    if not has_symbol:
        return False
    cleaned = s.replace(",", "").strip()
    stripped = cleaned.lstrip("".join(_CURRENCY_SYMBOLS)).rstrip("".join(_CURRENCY_SYMBOLS))
    try:
        float(stripped)
        return True
    except ValueError:
        return False


def _matches_percentage(s: str) -> bool:
    return bool(_PERCENTAGE_RE.match(s.replace(",", "")))


def _is_mixed(values: list[Any]) -> bool:
    types = {type(v) for v in values if not isinstance(v, bool)}
    return len(types) > 1


def _mixed_type_distribution(non_null: list[Any], total: int) -> list[dict[str, Any]]:
    counts: dict[str, int] = {}
    for value in non_null:
        type_name = _display_type_name(value)
        counts[type_name] = counts.get(type_name, 0) + 1

    return [
        {"type": type_name, "count": count, "pct": round(count / total * 100, 2)}
        for type_name, count in sorted(counts.items(), key=lambda x: (-x[1], x[0]))
    ]


def _display_type_name(value: Any) -> str:
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, datetime.datetime):
        return "datetime"
    if isinstance(value, datetime.date):
        return "date"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "float"
    if isinstance(value, str):
        return "text"
    return type(value).__name__


# --- Distribution summaries ---------------------------------------------------

def _distribution(inferred_type: str, non_null: list[Any], total: int) -> dict[str, Any]:
    if inferred_type in ("categorical", "string", "identifier", "mixed", "boolean"):
        return _categorical_distribution(non_null, total)
    return {}


def _numeric_distribution(non_null: list[Any]) -> dict[str, Any]:
    nums = sorted(_to_float(v) for v in non_null)
    if not nums:
        return {}
    return {
        "min": nums[0],
        "max": nums[-1],
        "mean": round(sum(nums) / len(nums), 4),
        "p25": _percentile(nums, 25),
        "p50": _percentile(nums, 50),
        "p75": _percentile(nums, 75),
    }


def _date_distribution(non_null: list[Any]) -> dict[str, Any]:
    sorted_dates = sorted(non_null)
    return {
        "min": str(sorted_dates[0]),
        "max": str(sorted_dates[-1]),
    }


def _categorical_distribution(non_null: list[Any], total: int) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for v in non_null:
        key = str(v).strip()
        counts[key] = counts.get(key, 0) + 1
    top = sorted(counts.items(), key=lambda x: x[1], reverse=True)[:10]
    return {
        "top_values": [
            {"rank": i, "count": c, "pct": round(c / total * 100, 2)}
            for i, (_k, c) in enumerate(top, start=1)
        ]
    }


def _to_float(v: Any) -> float:
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(",", "")
    s = s.strip("".join(_CURRENCY_SYMBOLS)).rstrip("%")
    return float(s)


def _percentile(sorted_vals: list[float], p: float) -> float:
    n = len(sorted_vals)
    if n == 0:
        return 0.0
    idx = (n - 1) * p / 100
    lo = int(idx)
    hi = lo + 1
    if hi >= n:
        return round(sorted_vals[-1], 4)
    return round(sorted_vals[lo] + (idx - lo) * (sorted_vals[hi] - sorted_vals[lo]), 4)
