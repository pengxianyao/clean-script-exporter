"""Writes profiler outputs: JSON, Markdown, and column summary CSV."""
from __future__ import annotations

import csv
import json
from io import StringIO
from pathlib import Path
from typing import Any

_JSON_FILENAME = "data_universe_profile.json"
_MD_FILENAME = "data_universe_profile.md"
_CSV_FILENAME = "column_summary.csv"


def write_all_outputs(profile: dict[str, Any], source_path: Path) -> dict[str, Path]:
    output_dir = source_path.parent / "output"
    output_dir.mkdir(exist_ok=True)
    return {
        "json": _write_json(profile, output_dir),
        "md": _write_markdown(profile, output_dir),
        "csv": _write_column_csv(profile, output_dir),
    }


# Keep for backwards compatibility with existing tests
def write_profile(profile: dict[str, Any], source_path: Path) -> Path:
    output_dir = source_path.parent / "output"
    output_dir.mkdir(exist_ok=True)
    return _write_json(profile, output_dir)


# --- JSON --------------------------------------------------------------------

def _write_json(profile: dict[str, Any], output_dir: Path) -> Path:
    path = output_dir / _JSON_FILENAME
    path.write_text(json.dumps(profile, indent=2, default=str), encoding="utf-8")
    return path


# --- Markdown ----------------------------------------------------------------

def _write_markdown(profile: dict[str, Any], output_dir: Path) -> Path:
    path = output_dir / _MD_FILENAME
    path.write_text(_build_markdown(profile), encoding="utf-8")
    return path


def _build_markdown(p: dict[str, Any]) -> str:
    lines: list[str] = []

    lines += [
        "# Data Universe Profile",
        "",
        f"**Source file:** {p['source_file']}  ",
        f"**Sheet:** {p['sheet_name']}  ",
        f"**Header row:** {p['header_row']}  ",
        f"**Total rows:** {p['total_rows']}  ",
        f"**Total columns:** {p['total_columns']}  ",
        f"**Profiled at:** {p['profiled_at']}",
        "",
    ]

    lines += _dataset_summary(p)

    lines += [
        "---",
        "",
        "## Columns",
        "",
    ]

    for col in p["columns"]:
        lines.append(f"### {col['name']}")
        lines.append("")

        narrative = _column_narrative(col)
        if narrative:
            lines.append(f"> {narrative}")
            lines.append("")

        lines.append(f"- **Type:** `{col['inferred_type']}`")
        lines.append(f"- **Null:** {col['null_count']} ({col['null_pct']}%)")
        lines.append(f"- **Unique:** {col['unique_count']} ({col['unique_pct']}%)")

        if "top_values" in col and col["top_values"]:
            lines.append("- **Top value frequencies:**")
            lines.append("")
            lines.append("  | Rank | Count | % |")
            lines.append("  |-----:|------:|--:|")
            for tv in col["top_values"]:
                lines.append(f"  | {tv['rank']} | {tv['count']} | {tv['pct']} |")

        if "identifier_pattern" in col:
            lines += _identifier_pattern_lines(col["identifier_pattern"])

        if col.get("mixed_types"):
            lines.append(f"- **Mixed types:** {_format_mixed_types(col)}")

        lines.append("")

    lines += [
        "---",
        "",
        "## Exact Mappings",
        "",
    ]

    lines += _mappings_narrative(p["exact_mappings"])

    if p["exact_mappings"]:
        lines.append("")
        lines.append("| Source Column | Target Column | Distinct Pairs |")
        lines.append("|---------------|---------------|---------------:|")
        for m in p["exact_mappings"]:
            lines.append(f"| {m['source_column']} | {m['target_column']} | {m['mapping_count']} |")

    lines.append("")

    if "sequence_analysis" in p:
        lines += _build_sequence_section(p["sequence_analysis"])

    return "\n".join(lines)


def _identifier_pattern_lines(pattern: dict[str, Any]) -> list[str]:
    lines: list[str] = []
    if "total_length_fixed" in pattern:
        fixed = "yes" if pattern["total_length_fixed"] else "no"
        lines.append(f"- **Fixed total length:** {fixed}")
    if "has_alpha_prefix" in pattern:
        prefix = "yes" if pattern["has_alpha_prefix"] else "no"
        lines.append(f"- **Has alpha prefix:** {prefix}")
    if "has_numeric_suffix" in pattern:
        suffix = "yes" if pattern["has_numeric_suffix"] else "no"
        lines.append(f"- **Has numeric suffix:** {suffix}")
    if "body_length" in pattern:
        lines.append(f"- **Body length:** {pattern['body_length']}")
    if pattern.get("has_leading_zeros"):
        lines.append("- **Has leading zeros:** yes")
    return lines


# --- Narrative generators ----------------------------------------------------

def _dataset_summary(p: dict[str, Any]) -> list[str]:
    cols = p["columns"]
    total = p["total_rows"]
    type_counts: dict[str, int] = {}
    for col in cols:
        t = col["inferred_type"]
        type_counts[t] = type_counts.get(t, 0) + 1

    type_summary = ", ".join(
        f"{count} {t}" for t, count in sorted(type_counts.items(), key=lambda x: -x[1])
    )

    null_cols = [c["name"] for c in cols if c["null_pct"] > 0]
    null_note = (
        f"{len(null_cols)} column(s) contain missing values "
        f"({', '.join(null_cols[:3])}{'...' if len(null_cols) > 3 else ''})."
        if null_cols else "No columns contain missing values."
    )

    return [
        f"This profile covers **{total} rows** and **{len(cols)} columns**. "
        f"Column types detected: {type_summary}. {null_note}",
        "",
    ]


def _column_narrative(col: dict[str, Any]) -> str:
    t = col["inferred_type"]
    name = col["name"]
    total = col["total_count"]
    null_pct = col["null_pct"]
    unique = col["unique_count"]

    null_note = ""
    if null_pct > 50:
        null_note = f" {null_pct}% of values are missing, suggesting this field is conditionally populated."
    elif null_pct > 0:
        null_note = f" {null_pct}% of values are missing."

    if t == "empty":
        return f"{name} contains no data; all values are blank."

    if t == "mostly_null":
        return f"{name} is almost entirely empty ({null_pct}% null). It may represent an optional or rarely-used field."

    if t == "identifier":
        pat = col.get("identifier_pattern", {})
        parts = [f"{name} contains structured identifier codes."]
        if pat.get("total_length_fixed"):
            parts.append("Values have a consistent total length.")
        if pat.get("has_alpha_prefix"):
            parts.append("Values include an alphabetic prefix.")
        if pat.get("has_numeric_suffix"):
            parts.append("Values include a numeric suffix.")
        if pat.get("has_leading_zeros"):
            parts.append("Leading zeros are present, so this column should be treated as text, not a number.")
        if unique == total:
            parts.append(f"All {total} values are unique, consistent with a primary or reference key.")
        return " ".join(parts) + null_note

    if t == "categorical":
        tv = col.get("top_values", [])
        n = unique
        if n == 2 and len(tv) >= 2:
            return (
                f"{name} is a binary column. The top two values account for "
                f"{tv[0]['pct']}% and {tv[1]['pct']}% of rows.{null_note}"
            )
        if tv and tv[0]["pct"] >= 60:
            second = f", followed by rank 2 at {tv[1]['pct']}%" if len(tv) > 1 else ""
            return (
                f"{name} has {n} distinct values. The most common value is heavily "
                f"dominant at {tv[0]['pct']}%{second}.{null_note}"
            )
        if tv and tv[0]["pct"] < 25:
            return f"{name} has {n} categories with no dominant value; values are spread relatively evenly.{null_note}"
        if tv:
            second = f", followed by rank 2 at {tv[1]['pct']}%" if len(tv) > 1 else ""
            return (
                f"{name} has {n} distinct values. The most common value accounts "
                f"for {tv[0]['pct']}%{second}.{null_note}"
            )

    if t in ("integer", "float", "currency", "percentage"):
        return f"{name} is a {t} column.{null_note}"

    if t in ("date", "datetime"):
        return f"{name} contains date-like values.{null_note}"

    if t == "boolean":
        tv = col.get("top_values", [])
        if len(tv) >= 2:
            return (
                f"{name} is a boolean column. The top two values account for "
                f"{tv[0]['pct']}% and {tv[1]['pct']}%.{null_note}"
            )
        return f"{name} is a boolean column.{null_note}"

    if t == "mixed":
        mixed = _format_mixed_types(col)
        mixed_note = f" Observed non-null types: {mixed}." if mixed else ""
        return (
            f"{name} contains mixed data types across its {total} rows. "
            f"This may indicate data quality issues or inconsistent formatting."
            f"{mixed_note}{null_note}"
        )

    if t == "string":
        if col["unique_pct"] >= 90:
            return (
                f"{name} contains free-text values with high uniqueness ({col['unique_pct']}%). "
                f"This likely represents descriptive or narrative content.{null_note}"
            )
        return f"{name} is a string column with {unique} distinct values across {total} rows.{null_note}"

    return ""


def _mappings_narrative(mappings: list[dict[str, Any]]) -> list[str]:
    if not mappings:
        return ["_No exact mappings detected._"]

    seen: set[tuple[str, str]] = set()
    unique_pairs: list[dict[str, Any]] = []
    for m in mappings:
        key = tuple(sorted([m["source_column"], m["target_column"]]))
        if key not in seen:
            seen.add(key)
            unique_pairs.append(m)

    count = len(unique_pairs)
    intro = (
        f"The profiler detected **{count} deterministic column relationship{'s' if count != 1 else ''}**. "
        f"In each case, knowing the value of one column completely determines the value of another; "
        f"these are likely lookup or derived fields."
    )
    lines = [intro, ""]

    for m in unique_pairs[:5]:
        lines.append(
            f"- **{m['source_column']}** always maps to exactly one **{m['target_column']}** value "
            f"across all {m['mapping_count']} distinct pair(s)."
        )

    if len(unique_pairs) > 5:
        lines.append(f"- _...and {len(unique_pairs) - 5} more; see full table below._")

    lines.append("")
    return lines


def _build_sequence_section(sa: dict[str, Any]) -> list[str]:
    lines = [
        "---",
        "",
        "## Sequence Analysis",
        "",
        f"- **Grouping column:** {sa['grouping_column']}",
        f"- **Sequence column:** {sa['sequence_column']}",
        f"- **Ordering column:** {sa['ordering_column']}",
        f"- **Total groups:** {sa['total_groups']}",
        f"- **Avg sequence length:** {sa['avg_sequence_length']}",
        "",
    ]

    if sa.get("entry_tasks"):
        lines += ["### Entry Tasks", ""]
        lines.append("| Task ID | Count | % |")
        lines.append("|---------|------:|--:|")
        for t in sa["entry_tasks"]:
            lines.append(f"| {t['value_id']} | {t['count']} | {t['pct']} |")
        lines.append("")

    if sa.get("exit_tasks"):
        lines += ["### Exit Tasks", ""]
        lines.append("| Task ID | Count | % |")
        lines.append("|---------|------:|--:|")
        for t in sa["exit_tasks"]:
            lines.append(f"| {t['value_id']} | {t['count']} | {t['pct']} |")
        lines.append("")

    if sa.get("transitions"):
        lines += ["### Transition Graph", ""]
        lines.append("| From ID | To ID | Count | % |")
        lines.append("|---------|-------|------:|--:|")
        for tr in sa["transitions"]:
            lines.append(f"| {tr['from_id']} | {tr['to_id']} | {tr['count']} | {tr['pct']} |")
        lines.append("")

    return lines


# --- CSV ---------------------------------------------------------------------

def _write_column_csv(profile: dict[str, Any], output_dir: Path) -> Path:
    path = output_dir / _CSV_FILENAME
    buf = StringIO()
    writer = csv.writer(buf)

    writer.writerow([
        "index", "name", "inferred_type",
        "total_count", "null_count", "null_pct",
        "unique_count", "unique_pct",
        "top_value_1_count", "top_value_1_pct",
        "has_alpha_prefix", "has_numeric_suffix", "body_length",
        "mixed_types",
    ])

    for col in profile["columns"]:
        tv = col.get("top_values", [])
        pattern = col.get("identifier_pattern", {})
        writer.writerow([
            col["index"],
            col["name"],
            col["inferred_type"],
            col["total_count"],
            col["null_count"],
            col["null_pct"],
            col["unique_count"],
            col["unique_pct"],
            tv[0]["count"] if tv else "",
            tv[0]["pct"] if tv else "",
            pattern.get("has_alpha_prefix", ""),
            pattern.get("has_numeric_suffix", ""),
            pattern.get("body_length", ""),
            _format_mixed_types(col),
        ])

    path.write_text(buf.getvalue(), encoding="utf-8")
    return path


def _format_mixed_types(col: dict[str, Any]) -> str:
    mixed_types = col.get("mixed_types", [])
    return "; ".join(
        f"{item['type']} ({item['count']}, {item['pct']}%)"
        for item in mixed_types
    )
