"""Exact-mapping cross-column relationship detection."""
from __future__ import annotations

from collections import defaultdict
from itertools import combinations
from typing import Any

_MAX_COLUMNS = 50
_MAX_UNIQUE_FOR_GROUPING = 50
_MAX_MASKED_ITEMS = 10
_MIN_OBSERVED_ROWS = 3
_MIN_GROUPS = 2
_MIN_COOCCURRENCE_COUNT = 2


def detect_exact_mappings(
    column_names: list[str],
    column_data: list[list[Any]],
) -> list[dict[str, Any]]:
    return detect_relationships(column_names, column_data)["exact_mappings"]


def detect_relationships(
    column_names: list[str],
    column_data: list[list[Any]],
) -> dict[str, list[dict[str, Any]]]:
    """Return exact mappings where every value of column A determines column B.

    Skips detection entirely if column count exceeds _MAX_COLUMNS.
    """
    if len(column_names) > _MAX_COLUMNS:
        return _empty_relationships()

    n = len(column_names)
    exact_mappings: list[dict[str, Any]] = []
    one_to_many: list[dict[str, Any]] = []
    co_occurrences: list[dict[str, Any]] = []
    composite_keys: list[dict[str, Any]] = []

    for a in range(n):
        for b in range(n):
            if a == b:
                continue
            exact = _check_exact_mapping(
                column_names[a], column_data[a],
                column_names[b], column_data[b],
            )
            if exact:
                exact_mappings.append(exact)
                continue

            one_many = _check_one_to_many(
                column_names[a], column_data[a],
                column_names[b], column_data[b],
            )
            if one_many:
                one_to_many.append(one_many)

    for a, b in combinations(range(n), 2):
        co = _check_co_occurrence(
            column_names[a], column_data[a],
            column_names[b], column_data[b],
        )
        if co:
            co_occurrences.append(co)

    for a, b in combinations(range(n), 2):
        for target in range(n):
            if target in (a, b):
                continue
            composite = _check_composite_key(
                (column_names[a], column_data[a]),
                (column_names[b], column_data[b]),
                (column_names[target], column_data[target]),
            )
            if composite:
                composite_keys.append(composite)

    return {
        "exact_mappings": exact_mappings,
        "one_to_many": one_to_many,
        "co_occurrences": co_occurrences,
        "composite_keys": composite_keys,
    }


def _check_exact_mapping(
    a_name: str, a_vals: list[Any],
    b_name: str, b_vals: list[Any],
) -> dict[str, Any] | None:
    seen: dict[Any, Any] = {}
    pair_counts: dict[tuple[str, str], int] = {}

    for a_val, b_val in zip(a_vals, b_vals):
        if _is_null(a_val) or _is_null(b_val):
            continue
        a_key = _normalise(a_val)
        b_key = _normalise(b_val)
        pair_counts[(a_key, b_key)] = pair_counts.get((a_key, b_key), 0) + 1
        if a_key in seen:
            if seen[a_key] != b_key:
                return None
        else:
            seen[a_key] = b_key

    if len(seen) < 2:
        return None

    return {
        "source_column": a_name,
        "target_column": b_name,
        "mapping_count": len(seen),
        "masked_pairs": _masked_pairs(a_name, b_name, pair_counts),
    }


def _check_one_to_many(
    a_name: str, a_vals: list[Any],
    b_name: str, b_vals: list[Any],
) -> dict[str, Any] | None:
    if not _is_groupable(a_vals) or not _is_groupable(b_vals):
        return None

    groups: dict[str, dict[str, int]] = defaultdict(dict)
    row_counts: dict[str, int] = defaultdict(int)
    for a_val, b_val in zip(a_vals, b_vals):
        if _is_null(a_val) or _is_null(b_val):
            continue
        a_key = _normalise(a_val)
        b_key = _normalise(b_val)
        groups[a_key][b_key] = groups[a_key].get(b_key, 0) + 1
        row_counts[a_key] += 1

    multi_groups = {
        source: targets
        for source, targets in groups.items()
        if len(targets) > 1
    }
    if len(multi_groups) < _MIN_GROUPS:
        return None

    source_aliases = _aliases(a_name, list(multi_groups))
    target_aliases = _aliases(
        b_name,
        [target for targets in multi_groups.values() for target in targets],
    )

    masked_groups = []
    for source, targets in sorted(
        multi_groups.items(),
        key=lambda item: (-len(item[1]), source_aliases[item[0]]),
    )[:_MAX_MASKED_ITEMS]:
        top_targets = sorted(targets.items(), key=lambda item: (-item[1], target_aliases[item[0]]))
        masked_groups.append({
            "source_id": source_aliases[source],
            "target_distinct_count": len(targets),
            "row_count": row_counts[source],
            "target_ids": [
                {
                    "target_id": target_aliases[target],
                    "count": count,
                }
                for target, count in top_targets[:_MAX_MASKED_ITEMS]
            ],
        })

    return {
        "source_column": a_name,
        "target_column": b_name,
        "group_count": len(multi_groups),
        "masked_groups": masked_groups,
    }


def _check_co_occurrence(
    a_name: str, a_vals: list[Any],
    b_name: str, b_vals: list[Any],
) -> dict[str, Any] | None:
    if not _is_groupable(a_vals) or not _is_groupable(b_vals):
        return None

    pair_counts: dict[tuple[str, str], int] = {}
    total = 0
    for a_val, b_val in zip(a_vals, b_vals):
        if _is_null(a_val) or _is_null(b_val):
            continue
        total += 1
        key = (_normalise(a_val), _normalise(b_val))
        pair_counts[key] = pair_counts.get(key, 0) + 1

    if total < _MIN_OBSERVED_ROWS:
        return None

    frequent_pairs = {
        pair: count
        for pair, count in pair_counts.items()
        if count >= _MIN_COOCCURRENCE_COUNT
    }
    if len(frequent_pairs) < _MIN_GROUPS:
        return None

    a_aliases = _aliases(a_name, [a for a, _b in frequent_pairs])
    b_aliases = _aliases(b_name, [b for _a, b in frequent_pairs])
    top_pairs = sorted(
        frequent_pairs.items(),
        key=lambda item: (-item[1], a_aliases[item[0][0]], b_aliases[item[0][1]]),
    )[:_MAX_MASKED_ITEMS]

    return {
        "columns": [a_name, b_name],
        "observed_pair_count": len(pair_counts),
        "row_count": total,
        "top_pairs": [
            {
                "left_id": a_aliases[a],
                "right_id": b_aliases[b],
                "count": count,
                "pct": round(count / total * 100, 2),
            }
            for (a, b), count in top_pairs
        ],
    }


def _check_composite_key(
    first: tuple[str, list[Any]],
    second: tuple[str, list[Any]],
    target: tuple[str, list[Any]],
) -> dict[str, Any] | None:
    a_name, a_vals = first
    b_name, b_vals = second
    target_name, target_vals = target

    if not _is_groupable(a_vals) or not _is_groupable(b_vals):
        return None

    seen: dict[tuple[str, str], str] = {}
    pair_counts: dict[tuple[tuple[str, str], str], int] = {}
    for a_val, b_val, target_val in zip(a_vals, b_vals, target_vals):
        if _is_null(a_val) or _is_null(b_val) or _is_null(target_val):
            continue
        key = (_normalise(a_val), _normalise(b_val))
        target_key = _normalise(target_val)
        pair_counts[(key, target_key)] = pair_counts.get((key, target_key), 0) + 1
        if key in seen and seen[key] != target_key:
            return None
        seen[key] = target_key

    if len(seen) < _MIN_OBSERVED_ROWS:
        return None

    source_aliases = _composite_aliases(a_name, b_name, list(seen))
    target_aliases = _aliases(target_name, list(seen.values()))
    masked_pairs = [
        {
            "source_id": source_aliases[source],
            "target_id": target_aliases[target_key],
            "count": count,
        }
        for (source, target_key), count in sorted(
            pair_counts.items(),
            key=lambda item: (source_aliases[item[0][0]], target_aliases[item[0][1]]),
        )[:_MAX_MASKED_ITEMS]
    ]

    return {
        "source_columns": [a_name, b_name],
        "target_column": target_name,
        "mapping_count": len(seen),
        "masked_pairs": masked_pairs,
    }


def _is_null(v: Any) -> bool:
    if v is None:
        return True
    return isinstance(v, str) and v.strip() == ""


def _normalise(v: Any) -> str:
    return str(v).strip().lower()


def _empty_relationships() -> dict[str, list[dict[str, Any]]]:
    return {
        "exact_mappings": [],
        "one_to_many": [],
        "co_occurrences": [],
        "composite_keys": [],
    }


def _is_groupable(values: list[Any]) -> bool:
    non_null = [_normalise(v) for v in values if not _is_null(v)]
    if len(non_null) < _MIN_OBSERVED_ROWS:
        return False
    unique_count = len(set(non_null))
    return 1 < unique_count <= _MAX_UNIQUE_FOR_GROUPING


def _masked_pairs(
    source_name: str,
    target_name: str,
    pair_counts: dict[tuple[str, str], int],
) -> list[dict[str, Any]]:
    source_aliases = _aliases(source_name, [source for source, _target in pair_counts])
    target_aliases = _aliases(target_name, [target for _source, target in pair_counts])

    return [
        {
            "source_id": source_aliases[source],
            "target_id": target_aliases[target],
            "count": count,
        }
        for (source, target), count in sorted(
            pair_counts.items(),
            key=lambda item: (source_aliases[item[0][0]], target_aliases[item[0][1]]),
        )
    ]


def _aliases(column_name: str, values: list[str]) -> dict[str, str]:
    return {
        value: f"{column_name}_{i}"
        for i, value in enumerate(sorted(set(values)), start=1)
    }


def _composite_aliases(
    first_name: str,
    second_name: str,
    values: list[tuple[str, str]],
) -> dict[tuple[str, str], str]:
    label = f"{first_name} + {second_name}"
    return {
        value: f"{label}_{i}"
        for i, value in enumerate(sorted(set(values)), start=1)
    }
