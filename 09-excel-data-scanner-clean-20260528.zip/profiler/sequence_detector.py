"""Sequential workflow detection — transition graph between task/step values."""
from __future__ import annotations

import datetime
from collections import defaultdict
from typing import Any

_MIN_COUNT = 2


def detect_sequences(
    column_names: list[str],
    column_data: list[list[Any]],
    grouping_col: str,
    sequence_col: str,
    ordering_col: str,
    min_count: int = _MIN_COUNT,
) -> dict[str, Any]:
    g_idx = column_names.index(grouping_col)
    s_idx = column_names.index(sequence_col)
    o_idx = column_names.index(ordering_col)

    num_rows = len(column_data[0]) if column_data else 0
    groups: dict[str, list[tuple[Any, str]]] = defaultdict(list)

    for i in range(num_rows):
        g_val = column_data[g_idx][i]
        s_val = column_data[s_idx][i]
        o_val = column_data[o_idx][i]
        if _is_null(g_val) or _is_null(s_val) or _is_null(o_val):
            continue
        groups[str(g_val).strip()].append((o_val, str(s_val).strip()))

    sequences: list[list[str]] = []
    for items in groups.values():
        try:
            sorted_items = sorted(items, key=lambda x: _sort_key(x[0]))
        except TypeError:
            sorted_items = sorted(items, key=lambda x: str(x[0]))
        sequences.append([item[1] for item in sorted_items])

    transition_counts: dict[tuple[str, str], int] = defaultdict(int)
    entry_counts: dict[str, int] = defaultdict(int)
    exit_counts: dict[str, int] = defaultdict(int)
    seq_lengths: list[int] = []

    for seq in sequences:
        seq_lengths.append(len(seq))
        if seq:
            entry_counts[seq[0]] += 1
            exit_counts[seq[-1]] += 1
        for j in range(len(seq) - 1):
            transition_counts[(seq[j], seq[j + 1])] += 1

    filtered = {k: v for k, v in transition_counts.items() if v >= min_count}
    total = sum(filtered.values())

    transitions = sorted(
        [
            {
                "from": frm,
                "to": to,
                "count": cnt,
                "pct": round(cnt / total * 100, 2) if total > 0 else 0.0,
            }
            for (frm, to), cnt in filtered.items()
        ],
        key=lambda x: x["count"],
        reverse=True,
    )

    total_groups = len(sequences)
    avg_length = round(sum(seq_lengths) / len(seq_lengths), 2) if seq_lengths else 0.0
    total_entries = sum(entry_counts.values())
    total_exits = sum(exit_counts.values())
    aliases = _sequence_aliases(entry_counts, exit_counts, transition_counts)

    return {
        "grouping_column": grouping_col,
        "sequence_column": sequence_col,
        "ordering_column": ordering_col,
        "total_groups": total_groups,
        "avg_sequence_length": avg_length,
        "entry_tasks": _rank(entry_counts, total_entries, aliases),
        "exit_tasks": _rank(exit_counts, total_exits, aliases),
        "transitions": _sanitize_transitions(transitions, aliases),
    }


def _sequence_aliases(
    entry_counts: dict[str, int],
    exit_counts: dict[str, int],
    transition_counts: dict[tuple[str, str], int],
) -> dict[str, str]:
    totals: dict[str, int] = defaultdict(int)
    for value, count in entry_counts.items():
        totals[value] += count
    for value, count in exit_counts.items():
        totals[value] += count
    for (frm, to), count in transition_counts.items():
        totals[frm] += count
        totals[to] += count

    ranked = sorted(totals.items(), key=lambda x: (-x[1], x[0]))
    return {value: f"step_{i}" for i, (value, _count) in enumerate(ranked, start=1)}


def _rank(
    counts: dict[str, int],
    total: int,
    aliases: dict[str, str],
) -> list[dict[str, Any]]:
    return sorted(
        [
            {
                "value_id": aliases[k],
                "count": v,
                "pct": round(v / total * 100, 2) if total > 0 else 0.0,
            }
            for k, v in counts.items()
        ],
        key=lambda x: x["count"],
        reverse=True,
    )


def _sanitize_transitions(
    transitions: list[dict[str, Any]],
    aliases: dict[str, str],
) -> list[dict[str, Any]]:
    return [
        {
            "from_id": aliases[transition["from"]],
            "to_id": aliases[transition["to"]],
            "count": transition["count"],
            "pct": transition["pct"],
        }
        for transition in transitions
    ]


def _is_null(v: Any) -> bool:
    if v is None:
        return True
    return isinstance(v, str) and v.strip() == ""


def _sort_key(v: Any) -> Any:
    if isinstance(v, (datetime.datetime, datetime.date, int, float)):
        return v
    return str(v)
