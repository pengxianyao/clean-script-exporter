# Excel Data Universe Profiler

Python tool for analysing an Excel workbook and producing a structured data-universe profile. The output describes column types, distributions, identifiers, exact mappings, and optional workflow sequences so a future synthetic data generator can recreate realistic datasets without exposing real source data.

## What It Produces

For a selected Excel sheet, the profiler writes three files into an `output/` folder beside the source workbook:

| File | Purpose |
| --- | --- |
| `data_universe_profile.json` | Machine-readable profile for downstream generators. |
| `data_universe_profile.md` | Human-readable profiling report. |
| `column_summary.csv` | Flat column-by-column summary for quick review. |

## What It Detects

- Column types: strings, numbers, currency, percentages, dates, booleans, categorical values, identifiers, mixed columns, mostly-null columns, and empty columns.
- Per-column statistics: nulls, unique values, numeric/date ranges, percentiles, and top values.
- Identifier patterns: prefixes, suffixes, numeric body lengths, leading zeros, fixed length, and regex hints.
- Exact mappings: one-column-to-one-column relationships such as code-to-name mappings.
- Optional workflow sequences: entry tasks, exit tasks, and transition graphs.

## Repository Layout

```text
.
|-- profiler/
|   |-- __main__.py
|   |-- file_loader.py
|   |-- sheet_selector.py
|   |-- header_resolver.py
|   |-- column_profiler.py
|   |-- identifier_detector.py
|   |-- relationship_detector.py
|   |-- sequence_detector.py
|   |-- sequence_prompter.py
|   |-- profile_builder.py
|   `-- output_writer.py
|-- tests/
|-- docs/
|-- CONTEXT.md
|-- pyproject.toml
|-- requirements.txt
`-- README.md
```

## Setup

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## Usage

```bash
python -m profiler
```

The tool will:

1. Open a file picker.
2. Ask which sheet to profile.
3. Ask which row contains headers.
4. Profile the sheet.
5. Optionally ask whether workflow sequence detection should run.
6. Write JSON, Markdown, and CSV outputs.

## Supported Formats

| Format | Support |
| --- | --- |
| `.xlsx` | Full support |
| `.xlsm` | Full support |
| `.xls` | Supported via `xlrd` |
| `.xlsb` | Not supported |
| `.csv` | Not supported |

## Tests

```bash
python -m pytest
```

## Limitations

- Designed for small-to-medium Excel files, roughly under 50k rows.
- Profiles one sheet per run.
- Formula cells are read from their cached values.
- Multiple tables on one sheet are treated as one table.
- Relationship detection is skipped automatically on very wide sheets.
