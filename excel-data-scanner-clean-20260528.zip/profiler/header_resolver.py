"""Header row prompt and column name extraction."""
from __future__ import annotations

from typing import Any


def resolve_headers(sheet_data: list[list[Any]]) -> tuple[int, list[str]]:
    """Prompt for header row, return (header_row_number, column_names)."""
    total_rows = len(sheet_data)
    if total_rows == 0:
        raise ValueError("Sheet is empty — cannot resolve headers.")

    header_row = _prompt_header_row(total_rows)
    raw_names = sheet_data[header_row - 1]
    column_names = _normalise_column_names(raw_names)
    return header_row, column_names


def _prompt_header_row(total_rows: int) -> int:
    while True:
        raw = input(f"Header row? [default: 1, max: {total_rows}]: ").strip()
        if raw == "":
            return 1
        try:
            row = int(raw)
            if 1 <= row <= total_rows:
                return row
            print(f"  Row {row} is out of range. Enter a number between 1 and {total_rows}.")
        except ValueError:
            print(f"  Invalid input: '{raw}'. Enter a row number or press Enter for default.")


def _normalise_column_names(raw: list[Any]) -> list[str]:
    names: list[str] = []
    seen: dict[str, int] = {}

    for i, val in enumerate(raw):
        base = str(val).strip() if val is not None and str(val).strip() != "" else f"Column_{i + 1}"

        if base not in seen:
            seen[base] = 1
            names.append(base)
        else:
            seen[base] += 1
            names.append(f"{base}_{seen[base]}")

    return names
