"""Identifier pattern extraction for identifier-typed columns."""
from __future__ import annotations

import re
from typing import Any


def detect_identifier_pattern(values: list[str]) -> dict[str, Any]:
    if not values:
        return {}

    prefix = _common_alpha_prefix(values)
    stripped = [v[len(prefix):] for v in values]
    suffix_sep, suffix_len = _detect_suffix(stripped)

    if suffix_sep:
        bodies = [s[:-(suffix_len + len(suffix_sep))] for s in stripped]
    else:
        bodies = stripped

    body_length = _common_body_length(bodies)
    total_length_fixed = len({len(v) for v in values}) == 1
    has_leading_zeros = _detect_leading_zeros(values, prefix)
    suffix_pattern = f"{suffix_sep}{'N' * suffix_len}" if suffix_sep else None
    regex_hint = _build_regex(prefix, bodies, body_length, suffix_sep, suffix_len)

    result: dict[str, Any] = {
        "prefix": prefix,
        "suffix_pattern": suffix_pattern,
        "total_length_fixed": total_length_fixed,
        "has_leading_zeros": has_leading_zeros,
        "regex_hint": regex_hint,
    }
    if body_length is not None:
        result["body_length"] = body_length

    return result


def _common_alpha_prefix(values: list[str]) -> str:
    def alpha_part(v: str) -> str:
        p = ""
        for c in v:
            if c.isdigit() or c in ("-", "_"):
                break
            p += c
        return p

    prefixes = [alpha_part(v) for v in values]
    common = prefixes[0]
    for p in prefixes[1:]:
        while common and not p.startswith(common):
            common = common[:-1]
    return common


def _detect_suffix(stripped: list[str]) -> tuple[str, int]:
    for sep in ("-", "_"):
        if not all(sep in s for s in stripped):
            continue
        parts = [s.rsplit(sep, 1)[1] for s in stripped]
        if all(p.isdigit() and p for p in parts):
            lengths = {len(p) for p in parts}
            if len(lengths) == 1:
                return sep, next(iter(lengths))
    return "", 0


def _detect_leading_zeros(values: list[str], prefix: str) -> bool:
    for v in values:
        after_prefix = v[len(prefix):]
        if len(after_prefix) > 1 and after_prefix[0] == "0" and after_prefix[1].isdigit():
            return True
    return False


def _common_body_length(bodies: list[str]) -> int | None:
    numeric = [b for b in bodies if b.isdigit()]
    if not numeric:
        return None
    lengths = {len(b) for b in numeric}
    return next(iter(lengths)) if len(lengths) == 1 else None


def _build_regex(
    prefix: str,
    bodies: list[str],
    body_length: int | None,
    suffix_sep: str,
    suffix_len: int,
) -> str:
    parts = ["^"]

    if prefix:
        parts.append(re.escape(prefix))

    if bodies and all(b.isdigit() for b in bodies if b):
        parts.append(f"[0-9]{{{body_length}}}" if body_length else "[0-9]+")
    else:
        body_lengths = {len(b) for b in bodies if b}
        parts.append(f".{{{next(iter(body_lengths))}}}" if len(body_lengths) == 1 else ".+")

    if suffix_sep and suffix_len:
        parts.append(suffix_sep)  # - and _ are literal outside []
        parts.append(f"[0-9]{{{suffix_len}}}")

    parts.append("$")
    return "".join(parts)
