"""File picker dialog and Excel workbook loader."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class LoadedWorkbook:
    source_path: Path
    sheet_names: list[str]
    _data: dict[str, list[list[Any]]] = field(repr=False)

    def get_sheet_data(self, sheet_name: str) -> list[list[Any]]:
        return self._data[sheet_name]


def pick_file() -> Path:
    try:
        import tkinter as tk
        from tkinter import filedialog
    except ImportError:
        raise SystemExit(
            "Error: tkinter is not available. "
            "Install it via your system package manager (e.g. 'sudo apt install python3-tk')."
        )

    root = tk.Tk()
    root.withdraw()
    path_str = filedialog.askopenfilename(
        title="Select Excel file",
        filetypes=[
            ("Excel files", "*.xlsx *.xlsm *.xls"),
            ("All files", "*.*"),
        ],
    )
    root.destroy()

    if not path_str:
        raise SystemExit("No file selected.")

    return Path(path_str)


def load_workbook(path: Path) -> LoadedWorkbook:
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    suffix = path.suffix.lower()

    if suffix in (".xlsx", ".xlsm"):
        return _load_openpyxl(path)
    elif suffix == ".xls":
        return _load_xlrd(path)
    else:
        raise ValueError(f"Unsupported file format: {suffix}")


def _load_openpyxl(path: Path) -> LoadedWorkbook:
    import openpyxl

    wb = openpyxl.load_workbook(path, data_only=True)
    data: dict[str, list[list[Any]]] = {
        name: [list(row) for row in wb[name].iter_rows(values_only=True)]
        for name in wb.sheetnames
    }
    return LoadedWorkbook(source_path=path, sheet_names=list(wb.sheetnames), _data=data)


def _load_xlrd(path: Path) -> LoadedWorkbook:
    try:
        import xlrd
    except ImportError:
        raise SystemExit(
            "Error: 'xlrd' is required to open .xls files. "
            "Install it with: pip install xlrd"
        )

    wb = xlrd.open_workbook(str(path))
    data: dict[str, list[list[Any]]] = {
        name: [wb.sheet_by_name(name).row_values(i) for i in range(wb.sheet_by_name(name).nrows)]
        for name in wb.sheet_names()
    }
    return LoadedWorkbook(source_path=path, sheet_names=list(wb.sheet_names()), _data=data)
