"""User prompts for opt-in sequential/workflow detection."""
from __future__ import annotations

import sys


def prompt_sequence_opt_in() -> bool:
    print()
    print("=" * 60)
    print("SEQUENTIAL / WORKFLOW DATA DETECTION (optional)")
    print("=" * 60)
    print(
        "Some sheets contain sequential data — the same entity\n"
        "(e.g. a portfolio or case) appears in multiple rows,\n"
        "each row representing a step or task in a process.\n"
        "\n"
        "If this sheet has that structure, the profiler can detect\n"
        "which steps follow which and how often (transition graph).\n"
        "\n"
        "If unsure, answer N to skip."
    )
    sys.stdout.flush()
    raw = input("\nDoes this sheet contain sequential/workflow data? [y/N]: ").strip().lower()
    return raw in ("y", "yes")


def prompt_sequence_columns(column_names: list[str]) -> tuple[str, str, str]:
    print("\nColumn list:")
    for i, name in enumerate(column_names, start=1):
        print(f"  {i}. {name}")
    sys.stdout.flush()

    grouping_col = _prompt_column(
        column_names,
        label="Grouping key column",
        help_text=(
            "The grouping key identifies each unique entity.\n"
            "  Rows sharing the same value are treated as one sequence.\n"
            "  Example: 'Portfolio Number' — all rows for SG12345678\n"
            "  form one sequence together."
        ),
    )

    sequence_col = _prompt_column(
        column_names,
        label="Sequence column",
        help_text=(
            "The sequence column holds the step or task values\n"
            "  that change across rows for the same entity.\n"
            "  Example: 'Task' — values like Task A, Task B, Task C."
        ),
        exclude=[grouping_col],
    )

    ordering_col = _prompt_column(
        column_names,
        label="Ordering column",
        help_text=(
            "The ordering column is a date or timestamp used to sort\n"
            "  the steps within each group into the correct sequence.\n"
            "  Example: 'Task Start' — the date each step began."
        ),
        exclude=[grouping_col, sequence_col],
    )

    return grouping_col, sequence_col, ordering_col


def _prompt_column(
    column_names: list[str],
    label: str,
    help_text: str,
    exclude: list[str] | None = None,
) -> str:
    excluded = set(exclude or [])
    print(f"\n{label}:")
    print(f"  {help_text}")
    sys.stdout.flush()

    while True:
        raw = input("  Enter number or column name: ").strip()

        try:
            idx = int(raw) - 1
            if 0 <= idx < len(column_names):
                name = column_names[idx]
                if name in excluded:
                    print(f"  '{name}' is already assigned to another role. Choose a different column.")
                    sys.stdout.flush()
                    continue
                return name
        except ValueError:
            pass

        if raw in column_names and raw not in excluded:
            return raw

        print(f"  Invalid. Enter a number (1-{len(column_names)}) or an exact column name.")
        sys.stdout.flush()
