"""Terminal sheet listing and selection."""
from __future__ import annotations

import sys


def select_sheet(sheet_names: list[str]) -> str:
    if len(sheet_names) == 1:
        print(f"\nOne sheet found: '{sheet_names[0]}' — selected automatically.")
        sys.stdout.flush()
        return sheet_names[0]

    _print_sheet_list(sheet_names)

    while True:
        raw = input("Select sheet (number or name): ").strip()
        result = _parse_selection(raw, sheet_names)
        if result is not None:
            return result
        print(f"  Invalid selection: '{raw}'. Enter a number (1-{len(sheet_names)}) or exact sheet name.")
        sys.stdout.flush()


def _print_sheet_list(sheet_names: list[str]) -> None:
    print("\nAvailable sheets:")
    for i, name in enumerate(sheet_names, start=1):
        print(f"  {i}. {name}")
    print()
    sys.stdout.flush()


def _parse_selection(raw: str, sheet_names: list[str]) -> str | None:
    if raw in sheet_names:
        return raw

    try:
        index = int(raw)
        if 1 <= index <= len(sheet_names):
            return sheet_names[index - 1]
    except ValueError:
        pass

    return None
