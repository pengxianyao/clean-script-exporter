"""Exact-mapping cross-column relationship detection."""
from __future__ import annotations

from typing import Any

_MAX_COLUMNS = 50


def detect_exact_mappings(
    column_names: list[str],
    column_data: list[list[Any]],
) -> list[dict[str, Any]]:
    """Return exact mappings where every value of column A determines column B.

    Skips detection entirely if column count exceeds _MAX_COLUMNS.
    """
    if len(column_names) > _MAX_COLUMNS:
        return []

    mappings = []
    n = len(column_names)

    for a in range(n):
        for b in range(n):
            if a == b:
                continue
            result = _check_exact_mapping(
                column_names[a], column_data[a],
                column_names[b], column_data[b],
            )
            if result:
                mappings.append(result)

    return mappings


def _check_exact_mapping(
    a_name: str, a_vals: list[Any],
    b_name: str, b_vals: list[Any],
) -> dict[str, Any] | None:
    seen: dict[Any, Any] = {}

    for a_val, b_val in zip(a_vals, b_vals):
        if _is_null(a_val) or _is_null(b_val):
            continue
        a_key = _normalise(a_val)
        b_key = _normalise(b_val)
        if a_key in seen:
            if seen[a_key] != b_key:
                return None
        else:
            seen[a_key] = b_key

    if len(seen) < 2:
        return None

    return {
        "source_column": a_name,
        "target_column": b_name,
        "mapping_count": len(seen),
    }


def _is_null(v: Any) -> bool:
    if v is None:
        return True
    return isinstance(v, str) and v.strip() == ""


def _normalise(v: Any) -> str:
    return str(v).strip().lower()
