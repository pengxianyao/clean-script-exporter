"""Assembles all detections into the final Data Universe Profile dict."""
from __future__ import annotations

import datetime
from pathlib import Path
from typing import Any

from profiler.identifier_detector import detect_identifier_pattern


def build_profile(
    source_path: Path,
    sheet_name: str,
    header_row: int,
    total_rows: int,
    column_profiles: list[dict[str, Any]],
    column_data: list[list[Any]],
    exact_mappings: list[dict[str, Any]],
    sequence_analysis: dict[str, Any] | None = None,
) -> dict[str, Any]:
    columns = [
        _attach_identifier_pattern(profile, column_data[profile["index"]])
        for profile in column_profiles
    ]

    profile: dict[str, Any] = {
        "source_file": source_path.name,
        "sheet_name": sheet_name,
        "header_row": header_row,
        "total_rows": total_rows,
        "total_columns": len(columns),
        "profiled_at": datetime.datetime.now().replace(microsecond=0).isoformat(),
        "columns": columns,
        "exact_mappings": exact_mappings,
    }

    if sequence_analysis is not None:
        profile["sequence_analysis"] = sequence_analysis

    return profile


def _attach_identifier_pattern(
    profile: dict[str, Any],
    values: list[Any],
) -> dict[str, Any]:
    if profile.get("inferred_type") != "identifier":
        return profile

    str_values = [str(v).strip() for v in values if v is not None and str(v).strip() != ""]
    pattern = detect_identifier_pattern(str_values)
    if pattern:
        return {**profile, "identifier_pattern": pattern}
    return profile
